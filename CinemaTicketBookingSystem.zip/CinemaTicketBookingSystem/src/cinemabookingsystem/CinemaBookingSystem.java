/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cinemabookingsystem;

/**
 *
 * @author WONG YUN XUAN
 */
public class CinemaBookingSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new WelcomeFrame().setVisible(true);
    }
    
}
